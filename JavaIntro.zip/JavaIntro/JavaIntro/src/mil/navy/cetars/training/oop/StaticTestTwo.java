package mil.navy.cetars.training.oop;

public class StaticTestTwo extends StaticTest{
	
	public static int returnValue() {
		return 3;
	}

}	
	
