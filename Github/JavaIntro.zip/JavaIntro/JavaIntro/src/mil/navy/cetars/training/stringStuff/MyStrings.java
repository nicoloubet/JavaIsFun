package mil.navy.cetars.training.stringStuff;



public class MyStrings extends Palindrome {

	
	// NOTE! Method should only execute one task. DO NOT try and over load the method with more than one task.
	 
	
	
	
	/**
	 * The result of calling this public method will be output to the console of every word that is a Palindrome.
	 * @return void 
	 * @param String[]
	 */
	
	@Override
	public void palindromeFinder(String[] myArray) {
	 //forloop to pull each string out 
	// then call reverse string method 
		
		for(String arr : myArray) {
			reverseString(arr);
			
		}
		
}
	
	
	
	//Reverse the string and compare
	@Override
	public void reverseString(String str) {
		
	
	String reverse = "";
		for(int i = str.length()-1; i > -1; i--) {
			reverse = (reverse + str.charAt(i)).toString();
		}
			
			if (str.equalsIgnoreCase(reverse))
		         System.out.println(str+" is a palindrome");
		      else
		         System.out.println(str+" is not a palindrome");
			
		}
	
	    
			//store current string in a variable and compare to reversed string
			//Compare if they match. If they match then it is a palindrome.
	}

	
	
	
	
	
	
	
	

