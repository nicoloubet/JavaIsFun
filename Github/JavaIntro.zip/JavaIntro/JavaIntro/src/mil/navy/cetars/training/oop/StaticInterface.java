package mil.navy.cetars.training.oop;

public interface StaticInterface {

	public int returnValue();
		
	
}
