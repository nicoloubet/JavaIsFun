package mil.navy.cetars.training.assignment7;


public abstract class MaxMin {
	
	public abstract void findMaxMinValue(int[] nums);
	
	public void run(int[] array) {
		this.findMaxMinValue(array);
		
	
	}
}
