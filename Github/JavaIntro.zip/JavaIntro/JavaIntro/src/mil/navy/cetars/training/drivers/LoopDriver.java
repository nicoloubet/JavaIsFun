package mil.navy.cetars.training.drivers;

import mil.navy.cetars.training.intro2.LoopsExample;

public class LoopDriver {

	public static void main(String[] args) {
		
		String[] Arr = {"Kevin", "Ben", "John", "Karen"};
		
		LoopsExample loopEx = new LoopsExample();
		loopEx.run(Arr);
		
	}

}
