package mil.navy.cetars.training.oop;


public class StaticTest {
	
	

	public static int returnValue() {
		return -1;
	}
}

