package mil.navy.cetars.training.assignment7;

public class MaxMinDriver {

	public static void main(String[] args) {
		
		int[] nums = {4,27,-13,8-9,15};
		
		ArrayRunner arrRun = new ArrayRunner();
		arrRun.run(nums);
		

	}

}
